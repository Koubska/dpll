#!/bin/sh

##### Python
echo "Python"
pypy3 dpll.py $*
